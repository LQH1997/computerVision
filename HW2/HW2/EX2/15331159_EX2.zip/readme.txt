编译命令为：
g++ -o canny.out canny.cpp main.cpp -O2 -L/usr/X11R6/lib -lm -lpthread -lX11